<?php
class Database {
    private static $dbHost     = "s334192.spinetail.cdu.edu.au";
    private static $dbUsername = "s334192_root";
    private static $dbPassword = "maruf1234";
    private static $dbName     = "s334192_news";
    public static $db;
    public static $table;

    public static function connect(){
        try{
            $conn = new PDO("mysql:host=".self::$dbHost.";dbname=".self::$dbName, self::$dbUsername, self::$dbPassword);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            return $conn;
        }catch(PDOException $e){
            die("Failed to connect with : " . $e->getMessage());
        }
    }

    public static function select($conditions = array()){
        $sql = 'SELECT ';
        $sql .= array_key_exists("select",$conditions)?$conditions['select']:'*';
        $sql .= ' FROM '.static::$table;
        $sql .= array_key_exists("where",$conditions)?$conditions['where']:' ';
        $sql .= array_key_exists("orderby",$conditions)?$conditions['orderby']:' ';
        $query = self::connect()->prepare($sql);
        $query->execute();
        $result =[];
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
            $result[] = $row;
        }
        return $result;
    }

    public static function insert( array $data){
        $columns = '';
        $values  = '';
        $i = 0;

        $columnString = implode(',', array_keys($data));
        $valueString = ":".implode(',:', array_keys($data));
        $sql = "INSERT INTO ".static::$table." (".$columnString.") VALUES (".$valueString.")";

        try{
            $query = self::connect()->prepare($sql);
            foreach($data as $key=>$val){
                $query->bindValue(':'.$key, $val);
            }
            $insert = $query->execute();
            return $insert? 'Success':false;
        } catch(Exception $e) {
            echo 'Exception -> ';
            echo $e->getMessage();
        }

    }

    public static function update($data,$conditions){
            $colvalSet = '';
            $whereSql = '';
            $i = 0;
            foreach($data as $key=>$val){
                $pre = ($i > 0)?', ':'';
                $colvalSet .= $pre.$key."='".$val."'";
                $i++;
            }
            if(!empty($conditions)&& is_array($conditions)){
                $whereSql .= ' WHERE ';
                $i = 0;
                foreach($conditions as $key => $value){
                    $pre = ($i > 0)?' AND ':'';
                    $whereSql .= $pre.$key." = '".$value."'";
                    $i++;
                }
            }
            $sql = "UPDATE ".static::$table." SET ".$colvalSet.$whereSql;
            $query = self::connect()->prepare($sql);
            $update = $query->execute();
            return $update ? 'Success':false;
    }

    public static function delete($conditions){
        $whereSql = '';
        if(!empty($conditions)&& is_array($conditions)){
            $whereSql .= ' WHERE ';
            $i = 0;
            foreach($conditions as $key => $value){
                $pre = ($i > 0)?' AND ':'';
                $whereSql .= $pre.$key." = '".$value."'";
                $i++;
            }
        }
        $sql = "DELETE FROM ".static::$table.$whereSql;
        $delete = self::connect()->query($sql);
        return $delete ? 'Success':false;
    }

}