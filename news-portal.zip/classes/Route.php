<?php

class Route
{
    public static $validRoutes = [];
    public static function set($route , $action)
    {
        // for xammp routing (removing project folder name)
        $server_request_uri = trim(str_replace(directory(), "",$_SERVER['REQUEST_URI']),"/");
        

        self::$validRoutes[] = $route;

        if(strpos($server_request_uri,"?")){
            $intended_route = explode("?" , $server_request_uri)[0];
        } else {
            $intended_route = $server_request_uri;
        }


        if($intended_route === $route){
            $action->__invoke();
        }

    }
}
