<?php
auth();
includeView('head');
includeView('admin-menu');
?>

<div class="container">
    <?php if(userJournalist()){ ?>
    <div class="row">
        <div class="col-md-12 mt-4">
            <h1 class="float-left">Create Articles</h1>
            <a href="#articles" class="float-right btn btn-primary">My Articles</a>
            <div class="login-form float-left w-100 d-block">

                <?php if(hasSession('error_message')){ ?>
                <div class="alert alert-danger">
                    <?php echo flashSession('error_message'); ?>
                </div>
                <?php } ?>

                <?php if(hasSession('success_message')){ ?>
                <div class="alert alert-success">
                    <?php echo flashSession('success_message'); ?>
                </div>
                <?php } ?>

               <form action="<?php directory_url(); ?>store-article" method="POST" enctype='multipart/form-data'>
                  <div class="form-group">
                     <label>Title*</label>
                     <input type="text" class="form-control" placeholder="Title" name="title" required>
                  </div>
                  <div class="form-group">
                     <label>Body*</label>
                     <textarea name="body" class="form-control" id="" cols="10" rows="5" required></textarea>
                  </div>
                  <div class="form-group">
                     <label>Folksonomies <small>(put comma between each other)</small></label>
                     <input type="text" class="form-control"  name="folksonomies" />
                  </div>
                  <div class="form-group">
                     <label>Tags <small>(put comma between each other)</small></label>
                     <input type="text" class="form-control"  name="tags" />
                  </div>
                  <div class="form-group">
                     <label>Image</small></label>
                     <input type="file" class="form-control"  name="image" />
                  </div>
                  <button type="submit" class="btn btn-black">Save</button>
               </form>
            </div>
        </div>
    </div>
    <?php } ?>
    <div class="row mt-5" id="articles">
        <div class="col-md-12">
            <h1> <?php echo (userJournalist()) ? 'My Articles' : 'Articles '; ?></h1>
            <?php foreach($data['articles'] as $article){ ?>
                <div class="card mt-3">
                    <div class="card-body">
                    <?php if(userJournalist()){ ?>
                        <a href="<?php directory_url(); ?><?php echo 'update-article?id=' . $article['id']; ?>" class="btn btn-success float-right">Update</a>
                    <?php } ?>

                    <?php if(userEditor()){ ?>
                        <a href="<?php directory_url(); ?><?php echo 'status-article?id=' . $article['id']; ?>" class="btn btn-success float-right"><?php echo ($article['status'] == 0) ? 'Publish'  : 'Unpublish' ?></a>
                    <?php } ?>



                        <form action="<?php directory_url(); ?>delete-article" method="POST">
                            <input type="hidden" name="id" value="<?php echo $article['id'] ?>">
                            <button type="submit" class="btn btn-danger mr-4 float-right">Delete</button>
                        </form>

                        <h4><?php echo $article['title']; ?></h4>
                        <p><?php echo $article['body']; ?></p>
                        <?php if($article['image']){ ?>
                        <img height="150" width="150" src="<?php directory_url(); ?><?php echo 'uploads/'. $article['image']; ?>" />
                        <?php }  ?>
                    </div>
                    <div class="row p-3">
                        <div class="col-md-4">
                            Tags:
                            <?php
                            foreach(explode("," ,$article['tags']) as $tag){ ?>
                                <small class="btn btn-secondary btn-sm"><?php echo $tag; ?></small>
                            <?php } ?>
                        </div>
                        <div class="col-md-4">
                        Folksonomies:
                            <?php
                            foreach(explode("," ,$article['folksonomies']) as $folk){ ?>
                                <small class="btn btn-secondary btn-sm"><?php echo $folk; ?></small>
                            <?php } ?>
                        </div>
                        <div class="col-md-4">
                            Last Updated At:
                            <?php
                            echo date("F jS, Y h:m:s", strtotime($article['updated_at']));
                            ?>
                        </div>
                    </div>
                </div>
            <?php } ?>



        </div>
    </div>
</div>


<?php
includeView('footer');
?>
