<?php
auth();
includeView('head');
includeView('admin-menu');
?>

<div class="container">
    <div class="row">
        <div class="col-md-12 mt-4">
            <h1 class="float-left">Update Articles</h1>
            <div class="login-form float-left w-100 d-block">

               <form action="<?php directory_url(); ?>post-update-article" method="POST" enctype='multipart/form-data'>
                  <div class="form-group">
                     <label>Title*</label>
                     <input type="text" class="form-control" value="<?php echo $data['title'] ?>" placeholder="Title" name="title" required>
                  </div>
                  <div class="form-group">
                     <label>Body*</label>
                     <textarea name="body" class="form-control" id="" cols="10" rows="5" required><?php echo $data['body'] ?></textarea>
                  </div>
                  <div class="form-group">
                     <label>Folksonomies <small>(put comma between each other)</small></label>
                     <input type="text" class="form-control"  name="folksonomies" value="<?php echo $data['folksonomies'] ?>" />
                  </div>
                  <div class="form-group">
                     <label>Tags <small>(put comma between each other)</small></label>
                     <input type="text" class="form-control"  name="tags" value="<?php echo $data['tags'] ?>" />
                  </div>
                  <input type="hidden"   name="id" value="<?php echo $data['id'] ?>" />

                  <button type="submit" class="btn btn-black">Update</button>
               </form>
            </div>
        </div>
    </div>
</div>


<?php
includeView('footer');
?>