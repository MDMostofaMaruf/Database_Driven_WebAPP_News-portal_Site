<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 , shrink-to-fit=no">
    <title>Austro-Asian Times</title>
    <link rel="stylesheet" href="<?php directory_url(); ?>assets/css/bootstrap.min.css" >
    <link rel="stylesheet" href="<?php directory_url(); ?>assets/css/main.css" >

</head>
<body>
