<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="<?php directory_url(); ?>">Austro-Asian Times</a>

  <div id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="<?php directory_url(); ?>dashboard/articles">Articles </a>
      </li>
      <?php if(userEditor()){ ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php directory_url(); ?>dashboard/users">Users</a>
      </li>
      <?php } ?>
      <li class="nav-item">
        <a class="nav-link" href="<?php directory_url(); ?>dashboard/comments">Comments</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php directory_url(); ?>dashboard/logout">Hi, <?php echo getSession('user_name'); ?> - Logout</a>
      </li>
    </ul>
  </div>
</nav>