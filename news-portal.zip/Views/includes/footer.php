
<script src="<?php directory_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?php directory_url(); ?>assets/js/bootstrap.min.js"></script>

</body>
</html>