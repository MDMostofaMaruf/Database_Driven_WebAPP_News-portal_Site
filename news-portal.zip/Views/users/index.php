<?php
auth();
includeView('head');
includeView('admin-menu');
?>

<div class="container">

    <div class="row">
        <div class="col-md-12 mt-4">
            <h1 class="float-left">Create User</h1>
            <a href="#articles" class="float-right btn btn-primary">All Users</a>
            <div class="login-form float-left w-100 d-block">

                <?php if(hasSession('error_message')){ ?>
                <div class="alert alert-danger">
                    <?php echo flashSession('error_message'); ?>
                </div>
                <?php } ?>

                <?php if(hasSession('success_message')){ ?>
                <div class="alert alert-success">
                    <?php echo flashSession('success_message'); ?>
                </div>
                <?php } ?>

               <form action="<?php directory_url(); ?>store-user" method="POST">
                  <div class="form-group">
                     <label>Username* (Don't use space in username)</label>
                     <input type="text" class="form-control" placeholder="Username" name="username" required>
                  </div>

                  <div class="form-group">
                     <label>Role*</label>
                     <select name="role" class="form-control" required>
                         <option value="">Select Role</option>
                         <option value="editor">Editor</option>
                         <option value="journalist">Journalist</option>
                     </select>
                  </div>

                  <div class="form-group">
                     <label>Password*</label>
                     <input type="password" class="form-control" name="password" required>
                  </div>

                  <button type="submit" class="btn btn-black">Save</button>
               </form>
            </div>
        </div>
    </div>


    <div class="row mt-5" id="users">
        <div class="col-md-12">
            <h1>Users</h1>
            <?php foreach($data['users'] as $user){ ?>
                <div class="card mt-3">
                    <div class="card-body">
                        <form action="<?php directory_url(); ?>delete-user" method="POST">
                            <input type="hidden" name="id" value="<?php echo $user['id'] ?>">
                            <button type="submit" class="btn btn-danger mr-4 float-right">Delete</button>
                        </form>
                        <h6>
                            Name:<?php echo $user['name']; ?> <br>
                            Role:   <?php echo ucwords($user['role']); ?>
                        </h6>
                    </div>
                </div>
            <?php } ?>



        </div>
    </div>
</div>



<?php
includeView('footer');
?>
