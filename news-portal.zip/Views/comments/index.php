<?php
auth();
includeView('head');
includeView('admin-menu');
?>

<div class="container">
    <div class="row mt-5">
        <div class="col-md-12">

        <?php if(hasSession('error_message')){ ?>
            <div class="alert alert-danger">
                <?php echo flashSession('error_message'); ?>
            </div>
            <?php } ?>

            <?php if(hasSession('success_message')){ ?>
            <div class="alert alert-success">
                <?php echo flashSession('success_message'); ?>
            </div>
            <?php } ?>

            <?php foreach($data['articles'] as $article){ ?>
                <div class="card mt-3">
                    <div class="card-body">

                        <h4>Article Title: <?php echo $article['title']; ?>  </h4>
                        <h6><u>Comments</u></h6>
                        <?php foreach($data['comments'] as $comment){ ?>
                            <?php if($comment['article_id'] == $article['id']){  ?>
                                <a href="<?php directory_url(); ?><?php echo 'status-article?id=' . $comment['id']; ?>" class="btn btn-success float-right"><?php echo $comment['status'] == '1' ? 'Unpublish' : 'Publish' ?></a>

                                <h5>( <?php echo $comment['status'] == '1' ? 'Published' : 'Unpublished' ?> )
                                <p><?php echo $comment['name'] . ' says: ' . $comment['comment']; ?></p>


                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>
</div>

<?php
includeView('footer');
?>
