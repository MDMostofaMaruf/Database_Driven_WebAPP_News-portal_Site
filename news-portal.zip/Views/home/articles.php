<?php
includeView('head');
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12 ">
            
            
            <?php if(hasSession('user_id')){ ?>
<a href="<?php directory_url(); ?>dashboard/articles" class="btn btn-primary w-100 float-left d-block mb-5">Admin Dashboard</a>
<?php }  else {?>


<a href="<?php directory_url(); ?>login" class="btn btn-primary w-100 float-left d-block mb-5">Admin Login</a>
<?php } ?>
            
            
            
            
        <h1 class="float-left d-inline-block w-50">All Articles</h1>
            <a class="float-right btn btn-primary d-inline-block w-50" href="<?php directory_url(); ?>">Top 5 Articles</a>
            <?php foreach($data['articles'] as $article){ ?>
                <div class="card mt-3 float-left w-100">
                    <div class="card-body">
                        <h4><?php echo $article['title']; ?></h4>
                        <p><?php echo substr_replace($article['body'] , "..." , 500); ?>
                        <a href="<?php directory_url(); ?><?php echo 'article?id=' . $article['id'] ; ?>" class="btn btn-secondary">Read More or Write a comment</a>
                        </p>
                        <?php if($article['image']){ ?>
                        <img height="150" width="150" src="<?php directory_url(); ?><?php echo 'uploads/'. $article['image']; ?>" />
                        <?php } ?>
                    </div>
                    <div class="row p-3">
                        <div class="col-md-4">
                            Tags:
                            <?php
                            foreach(explode("," ,$article['tags']) as $tag){ ?>
                                <small class="btn btn-secondary btn-sm"><?php echo $tag; ?></small>
                            <?php } ?>
                        </div>
                        <div class="col-md-4">
                        Folksonomies:
                            <?php
                            foreach(explode("," ,$article['folksonomies']) as $folk){ ?>
                                <small class="btn btn-secondary btn-sm"><?php echo $folk; ?></small>
                            <?php } ?>
                        </div>
                        <div class="col-md-4">
                            Last Updated At:
                            <?php
                            echo date("F jS, Y h:m:s", strtotime($article['updated_at']));
                            ?>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<?php
includeView('footer');
?>