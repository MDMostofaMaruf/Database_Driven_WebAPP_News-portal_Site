<?php
includeView('head');
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">

            <a class="float-left btn btn-primary d-inline-block w-50 mt-3 " href="<?php directory_url(); ?>">Top 5 Articles</a>
            <a class="float-right btn btn-primary d-inline-block w-50 mt-3 " href="<?php directory_url(); ?>articles">All Articles</a>


            <div class="card mt-3 float-left mb-4 w-100">
                <div class="card-body">
                    <h4><?php echo $data['article'][0]['title']; ?></h4>
                    <p><?php echo $data['article'][0]['body']; ?></p>
                    <?php if($data['article'][0]['image']){ ?>
                    <img height="150" width="150" src="<?php directory_url(); ?><?php echo 'uploads/'. $data['article'][0]['image']; ?>" />
                    <?php } ?>
                </div>
                <div class="row p-3">
                    <div class="col-md-4">
                        Tags:
                        <?php
                        foreach(explode("," ,$data['article'][0]['tags']) as $tag){ ?>
                            <small class="btn btn-secondary btn-sm"><?php echo $tag; ?></small>
                        <?php } ?>
                    </div>
                    <div class="col-md-4">
                    Folksonomies:
                        <?php
                        foreach(explode("," ,$data['article'][0]['folksonomies']) as $folk){ ?>
                            <small class="btn btn-secondary btn-sm"><?php echo $folk; ?></small>
                        <?php } ?>
                    </div>
                    <div class="col-md-4">
                        Last Updated At:
                        <?php
                        echo date("F jS, Y h:m:s", strtotime($data['article'][0]['updated_at']));
                        ?>
                    </div>
                </div>
            </div>

            <?php if(hasSession('error_message')){ ?>
                <div class="alert alert-danger float-left w-100">
                    <?php echo flashSession('error_message'); ?>
                </div>
            <?php } ?>

            <?php if(hasSession('success_message')){ ?>
                <div class="alert alert-success float-left w-100">
                    <?php echo flashSession('success_message'); ?>
                </div>
            <?php } ?>


            <h6 class="mt-4">Write a comment</h6>
            <div class="card mt-3 float-left w-100 p-4">
                <form action="<?php directory_url(); ?>store-comment" method="POST">
                  <div class="form-group">
                     <label>Name*</label>
                     <input type="text" class="form-control" placeholder="Name" name="name" required>
                  </div>

                  <div class="form-group">
                     <label>Body*</label>
                     <textarea name="comment" class="form-control" id="" cols="10" rows="5" required></textarea>
                  </div>


                  <button type="submit" class="btn btn-black">Comment</button>
               </form>
            </div>
            <?php
            if($data['comments']){
                foreach($data['comments'] as $comment){ ?>
                    <div class="card mt-3 float-left w-100 p-4">
                        <h5 class="card-title"><?php echo $comment['name']. ' says:'; ?></h5>
                        <div class="card-body">
                            <p><?php echo $comment['comment']; ?></p>
                        </div>
                    </div>
            <?php
                }
            } ?>
        </div>
    </div>
</div>

<?php
includeView('footer');
?>