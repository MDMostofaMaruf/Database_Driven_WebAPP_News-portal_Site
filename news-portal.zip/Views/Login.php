<?php
guest();
includeView('head');
?>

<div class="main-login py-5">
     <a class="text-center display-4 d-block m-auto" href="<?php directory_url(); ?>" style="color: black; font-weight:bold;">Home </a>
     
    <h1 class="text-center">Austro-Asian Times News Portal Login </h1>
   
         <div class="col-md-6 col-sm-12 m-auto">
            <div class="login-form">
                <?php if(hasSession('error_message')){ ?>
                <div class="alert alert-danger">
                    <?php echo flashSession('error_message'); ?>
                </div>
                <?php } ?>
               <form action="<?php directory_url(); ?>login-post" method="POST">
                  <div class="form-group">
                     <label>User Name</label>
                     <input type="text" class="form-control" placeholder="User Name" name="username" required>
                  </div>
                  <div class="form-group">
                     <label>Password</label>
                     <input type="password" class="form-control" placeholder="Password" name="password" required>
                  </div>
                  <button type="submit" class="btn btn-black">Login</button>
               </form>
            </div>
         </div>
      </div>


<?php
includeView('footer');
?>