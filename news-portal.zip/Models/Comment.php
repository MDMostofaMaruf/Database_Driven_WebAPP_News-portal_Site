<?php

class Comment extends Model {
    public static $table = 'comments';
}