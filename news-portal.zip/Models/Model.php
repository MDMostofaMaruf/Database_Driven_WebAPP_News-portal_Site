<?php

class Model extends Database {

}