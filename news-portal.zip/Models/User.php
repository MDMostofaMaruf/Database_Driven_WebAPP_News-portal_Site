<?php

class User extends Model {
    public static $table = 'users';
}