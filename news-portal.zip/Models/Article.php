<?php

class Article extends Model {
    public static $table = 'articles';
}