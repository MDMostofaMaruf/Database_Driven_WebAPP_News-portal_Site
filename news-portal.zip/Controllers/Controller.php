<?php
class Controller
{

    public static function view($view,$data =[])
    {
        $data = $data;
        require_once("./Views/" . $view . ".php");
    }
}
