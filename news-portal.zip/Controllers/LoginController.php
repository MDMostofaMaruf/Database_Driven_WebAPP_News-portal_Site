<?php

class LoginController extends Controller
{
    public static function ViewLogin()
    {
        self::view('Login');
    }

    public static function PostLogin()
    {
        if(isset($_POST['username']) && isset($_POST['password'])){
            $user = User::select([
                'select' => '*',
                'where' => " WHERE username = '" .$_POST['username']."'"
            ]);
            
            if($user && password_verify($_POST['password'] , $user[0]['password'])){
                setSession('user_id' , $user[0]['id']);
                setSession('user_name' , $user[0]['name']);
                setSession('user_role' , $user[0]['role']);
                redirect('/dashboard/articles');
            } else {
                setSession('error_message' , 'These Credentials doesn\'t match!');
                back();
            }
        }
    }

}
