<?php
class UserController extends Controller {
    public static function index()
    {
        $data['users'] = User::select(['where' => ' where id !=' . getSession('user_id')]);
        self::view('users/index' ,$data);
    }

    public static function store()
    {
        if($_POST){
            $user = User::insert([
                'username' => strtolower($_POST['username']),
                'name' => ucwords($_POST['username']),
                'role' => $_POST['role'],
                'password' => password_hash($_POST['password'] , PASSWORD_BCRYPT),
            ]);
        }

        if($user){
            setSession("success_message" , "User was created successfully!");
            back();

        }
    }

    public static function delete()
    {
        $user = User::delete(['id' => $_POST['id']]);
        if($user){
            setSession("success_message" , "User was deleted successfully!");
            back();
        }
    }

    public static function logout()
    {
        destroySession('user_id');
        destroySession('user_name');
        destroySession('user_role');
        redirect('/login');
    }
}
?>