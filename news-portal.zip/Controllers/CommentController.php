<?php
class CommentController extends Controller {
    public static function store(){
        if(isset($_POST)){
            $id = explode("=" , explode("?" , $_SERVER['HTTP_REFERER'])[1])[1];

            $comment = Comment::insert([
                'name' => $_POST['name'],
                'comment' => $_POST['comment'],
                'article_id' => $id
            ]);

            if($comment){
                setSession("success_message" , "Comment created!");
                back();
            }
        }
    }

    public static function index()
    {
        $articleSql =  userEditor() ? ' ORDER BY id DESC ' : ' WHERE user_id = ' . getSession('user_id') . ' ORDER BY id DESC ';

        $data['articles'] = Article::select([
            'orderby' => $articleSql
        ]);

        $data['comments'] = Comment::select([
            'orderby' => ' ORDER BY id DESC '
        ]);

        self::view('comments/index', $data);
    }

    public static function statusChange()
    {
        $id = explode("=" , explode("?" , $_SERVER['REQUEST_URI'])[1])[1];

        $comment  = Comment::select(['where' => ' where id = ' .$id .' '])[0];
        $status = ($comment['status'] == 1) ? 0 : 1;

        Comment::update(['status' => $status] , [
            'id' => $id
        ]);

        setSession("success_message" , "Comment's status changed!");
        back();

    }
}

?>