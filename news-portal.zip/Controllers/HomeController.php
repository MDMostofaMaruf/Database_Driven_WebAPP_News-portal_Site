<?php
class HomeController extends Controller {
    public static function index()
    {
        $data['articles'] = Article::select([
            'where' => '  where status = 1 ',
            'orderby' => '  ORDER BY updated_at DESC  LIMIT 5 ',
        ]);

        self::view('home/index' , $data);
    }

    public static function ShowArticles()
    {
        $data['articles'] = Article::select([
            'where' => '  where status = 1 ',
            'orderby' => ' ORDER BY updated_at DESC ',
        ]);

        self::view('home/articles' , $data);
    }

    public static function ShowArticle()
    {
        // getting id from url
        $id = explode("=" , explode("?" , $_SERVER['REQUEST_URI'])[1])[1];
        $data['article']  = Article::select(['where' => ' where id = ' .$id .' ']);
        $data['comments']  = Comment::select([
            'where' => ' where article_id = ' .$id .' AND status = 1 ',
            'orderby' => ' ORDER BY id DESC '
            ]);

        self::view('home/article' , $data);
    }
}
?>