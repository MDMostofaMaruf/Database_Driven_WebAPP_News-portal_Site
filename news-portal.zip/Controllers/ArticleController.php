<?php
class ArticleController extends Controller {

    public static function CreateArticle()
    {
        if(userJournalist()){
            $data['articles'] = Article::select([
                'where' => ' where user_id = '. getSession('user_id'),
                'orderby' => '  ORDER BY updated_at DESC ',
            ]);
        } elseif(userEditor()){
            $data['articles'] = Article::select([
                'orderby' => '  ORDER BY updated_at DESC '
            ]);
        }
        self::view('articles/index' , $data);
    }

    public static function StoreArticle()
    {
        if(isset($_POST)){

            if(isset($_FILES['image'])){
                //Process the image that is uploaded by the user
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($_FILES["image"]["name"]);
                $uploadOk = 1;
                $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);

                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    $image = basename( $_FILES["image"]["name"],$imageFileType). $imageFileType;
                }
            }
            $article = Article::insert([
                'title' => $_POST['title'],
                'body' => $_POST['body'],
                'user_id' => getSession('user_id'),
                'folksonomies' => $_POST['folksonomies'] ?? null,
                'tags' => $_POST['tags'] ?? null,
                'image' => $image ?? null,
                'updated_at' => date("Y-m-d H:i:s"),
            ]);

            if($article){
                setSession("success_message" , "Article was created successfully!");
            } else {
                setSession("error_message" , "Article was not created!");
            }
            back();
        }
    }

    public static function DeleteArticle()
    {
        $article = Article::delete(['id' => $_POST['id']]);
        if($article){
            setSession("success_message" , "Article was deleted successfully!");
            back();
        }
    }

    public static function UpdateArticle()
    {
        // getting id from url
        $id = explode("=" , explode("?" , $_SERVER['REQUEST_URI'])[1])[1];
        $data  = Article::select(['where' => ' where id = ' .$id .' ']);

        self::view('articles/update' , $data[0]);
    }

    public static function UpdatePostArticle()
    {
        if(isset($_POST)){
            $article = Article::update([
                'title' => $_POST['title'],
                'body' => $_POST['body'],
                'user_id' => getSession('user_id'),
                'folksonomies' => $_POST['folksonomies'] ?? null,
                'tags' => $_POST['tags'] ?? null,
                'updated_at' => date("Y-m-d H:i:s"),
            ] , ['id' => $_POST['id'] ]);

            if($article){
                setSession("success_message" , "Article was updated successfully!");
                redirect('dashboard/articles');
            }
        }
    }

    public static function statusChange()
    {
        $id = explode("=" , explode("?" , $_SERVER['REQUEST_URI'])[1])[1];

        $article = Article::select(['where' => ' where id='. $id .' '])[0];

        $status  = ($article['status'] == 0)  ? 1: 0;

        $article = Article::update([
            'status' => $status
        ],['id' => $id]);

        setSession("success_message" , "Article's status was changed successfully!");
        back();

    }

}